﻿/* External Variables 

day
month
year

*/

function addBDayTermsValidation(birthdayMessage) {
    $.validator.addMethod("birthDayValid", function (value, element, param) {
        showOneBirthdayError();
        return value != '';
    }, birthdayMessage);
    $.validator.addMethod("termsValid", function (value, element, param) {
        return validateTerms();
    });
    $('#Birthday_Year').rules("add", {
        birthDayValid: true
    });
    $('#Birthday_Month').rules("add", {
        birthDayValid: true
    });
    $('#Birthday_Day').rules("add", {
        birthDayValid: true
    });
    $('#Terms').rules("add", {
        termsValid: true
    });
}

function showOneBirthdayError() {
    if ($('#birthdayError .field-validation-error').length > 0) {
        $('#birthdayError span[data-valmsg-replace=true]').hide();
        $($('#birthdayError .field-validation-error')[0]).show();
        $('#birthdayError').show();
    } else $('#birthdayError').hide();
}

function validateTerms() {
    if ($('#Terms').length > 0) {
        if ($('#Terms:checked').val() == "true") {
            $('#Terms').parent().removeClass('error');
            return true;
        } else {
            $('#Terms').parent().addClass('error');
            return false;
        }
    } else return true;
}

function setDateField(prefix) {
    var y = $("#" + prefix + "_year").val();
    var m = $("#" + prefix + "_month").val()
    var d = $("#" + prefix + "_day").val();
    var newDate = d + "/" + m + "/" + y;
    $("#" + prefix).val(newDate);
}

function setDaysL(prefix) {
    var y = $("#" + prefix + "_Year").val();
    var m = $("#" + prefix + "_Month").val();
    var oldVal = $("#" + prefix + "_Day").val();
    ammount = new Date(y, m, 0).getDate();
    var dayWord = typeof(day)!= "undefined" ? ('- ' + day + ' -') : $($("#" + prefix + "_Day").children()[0]).text();
    $("#" + prefix + "_Day").children().remove().end().append("<option value=''>- " + dayWord + " -</option>");
    for (var i = 1; i <= ammount; i++) {
        var optionStr = "<option value='" + i + "'";
        if (i == oldVal)
            optionStr += " selected='selected'";
        optionStr += ">" + i + "</option>";
        $("#" + prefix + "_Day").children().end().append(optionStr);
    }
}

function setDaysLID(element) {
    var elementId = $(element).attr("id");
    setDaysL(elementId.substring(0, elementId.lastIndexOf("_")));
}

/*function setYearsList(prefix, yearsBack) {
    var yearNow = new Date().getFullYear();
    var oldVal = $("#" + prefix + "_Year").val();
    $("#" + prefix + "_Year").children().remove().end().append("<option value=''>- שנה -</option>");
    for (var i = yearNow; i > yearNow - yearsBack; i--) {
        var optionStr = "<option value='" + i + "'";
        if (i == oldVal)
            optionStr += " selected='selected'";
        optionStr += ">" + i + "</option>";
        $("#" + prefix + "_Year").children().end().append(optionStr);
    }
}*/

function setYearsList(prefix, minAge, maxAge) {
    var yearNow = new Date().getFullYear();
    var oldVal = $("#" + prefix + "_Year").val();
    var yearWord = typeof(year)!="undefined" ? ('- ' + year + ' -') : $($("#" + prefix + "_Year").children()[0]).text();
    $("#" + prefix + "_Year").children().remove().end().append("<option value=''>" + yearWord + "</option>");
    for (var i = (yearNow - minAge) ; i > yearNow - maxAge; i--) {
        var optionStr = "<option value='" + i + "'";
        if (i == oldVal)
            optionStr += " selected='selected'";
        optionStr += ">" + i + "</option>";
        $("#" + prefix + "_Year").children().end().append(optionStr);
    }
}

function setYearsListOfYearElement(element, yearsBack) {
    var yearNow = new Date().getFullYear();
    var oldVal = $(element).val();
    var yearWord = typeof (year) != "undefined" ? ('- ' + year + ' -') : $($(element).children()[0]).text();
    $(element).children().remove().end().append("<option value=''>- " + yearWord + " -</option>");
    for (var i = yearNow; i > yearNow - yearsBack; i--) {
        var optionStr = "<option value='" + i + "'";
        if (i == oldVal)
            optionStr += " selected='selected'";
        optionStr += ">" + i + "</option>";
        $(element).children().end().append(optionStr);
    }
}

//----------------------------------Private Zone Stuff--------------------------

function initSavingVisual() {
    $("#saveBtn").attr("disabled", true);
    $("#loadingImg").css("visibility", "visible");
}

function disposeSavingVisual() {
    $("#loadingImg").css("visibility", "hidden");
    $("#saveBtn").attr("disabled", false);
}

function saveAjax(funcName) {
    var d = $("form:first").serialize();
    var lang = getUrlVars()["lang"];
    if (lang != null) {
        d+= ('&lang='+lang);
    }
    $.ajax({
        type: "POST",
        url: funcName,
        data:d,
        success: function (result) {
            switch (result) {
                case "0":
                    $("#loadingImg").css("visibility", "hidden");
                    alert($("#infoSavedSpan").text());
                    $("#saveBtn").attr("disabled", false);
                    /*$("#infoSavedSpan").show().delay(1500).fadeOut(1000, function () {
                    $("#saveBtn").attr("disabled", false);
                    });*/
                    break;
                case "4":
                    disposeSavingVisual();
                    $("<span class=\"required\"> * </span>").replaceAll("span.placeHolder");
                    alert("נא למלא פרטי בן/בת זוג.");
                    break;
                case "5":
                    disposeSavingVisual();
                    alert("שגיאה. הסיסמה שהקשת אינה תואמת לרישומינו.");
                    break
                default:
                    disposeSavingVisual();
                    alert("שגיאה. הנתונים לא נשמרו.");
            }
        },
        error: function (req, status, error) {
            disposeSavingVisual();
            alert("שגיאה. הנתונים לא נשמרו.");
        }
    });
}

function getUrlVars()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

